/*************************************************************************
    > File Name: 1.c
    > Author: yuhaitao
    > Mail:acer_yuhaitao@163.com 
    > Created Time: Sun 19 Jun 2016 01:02:10 AM PDT
 ************************************************************************/

#include <stdio.h>
int main(int argc, char *argv[])
{
	  
}
